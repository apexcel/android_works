package com.example.projectt;

import android.os.Environment;

public class MyValues {
    public static String wordSetName = "";
    public static String lines = "";
    public static final String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString();
    public static final String testPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString() + "/test";
    public static String tempFileName = "";
    public static String testLines = "";
    public static String sendFilename = "";
}
