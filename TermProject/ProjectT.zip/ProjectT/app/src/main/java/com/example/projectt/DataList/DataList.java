package com.example.projectt.DataList;

public class DataList {
    private String kor;
    private String eng;


    public void setKor(String kor) {
        this.kor = kor;
    }

    public String getKor() {
        return kor;
    }

    public void setEng(String eng) {
        this.eng = eng;
    }

    public String getEng() {
        return eng;
    }
}